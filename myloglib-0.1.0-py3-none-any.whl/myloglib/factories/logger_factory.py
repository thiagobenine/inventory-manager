import logging.config

from myloglib.factories.config_builder import LoggingConfigBuilder
from myloglib.loggers.standard_logger import StandardLogger


class LoggerFactory:
    @staticmethod
    def build_default_logger(name: str, level: str = "INFO") -> StandardLogger:
        config_builder = LoggingConfigBuilder.get_default(name, level)
        logger_config = config_builder.build()
        logging.config.dictConfig(logger_config)
        return StandardLogger.create(name)