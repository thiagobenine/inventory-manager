import logging
from typing import Self
from myloglib.formatters.new_relic_correlation import CorrelationIDNewRelicContextFormatter
from myloglib.loggers.standard_logger import StandardLogger
from contextvars import ContextVar
from typing import Optional

class LoggingConfigBuilder:
    def __init__(self):
        self.handlers = []
        self.formatters = {}

    def add_formatter(self, name: str, formatter_class, **kwargs) -> Self:
        formatter = formatter_class(**kwargs)
        self.formatters[name] = formatter
        return self

    def add_handler(self, name: str, handler_class, formatter: str, **kwargs) -> Self:
        handler = handler_class(**kwargs)
        handler.setFormatter(self.formatters[formatter])
        self.handlers.append(handler)
        return self

    def build_logger(self, name: str, level: str = "INFO") -> StandardLogger:
        logger = logging.getLogger(name)
        logger.setLevel(level)
        for handler in self.handlers:
            logger.addHandler(handler)

        return StandardLogger(logger, name)

    @classmethod
    def build_default_logger(
        cls, 
        name: str, 
        correlation: Optional[ContextVar] = None,
        level: str = "INFO"
    ) -> StandardLogger:
        builder = cls()

        builder.add_formatter(
            name="json_formatter",
            formatter_class=CorrelationIDNewRelicContextFormatter,
            correlation_id=correlation,
        )
        builder.add_handler(
            name="console",
            handler_class=logging.StreamHandler,
            formatter="json_formatter"
        )

        logger = builder.build_logger(name, level)
        return logger
