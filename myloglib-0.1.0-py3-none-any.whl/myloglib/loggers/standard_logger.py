import logging
from typing import Any, Self, Optional
from logging import Logger

class StandardLogger:
    _instances: dict[str, Self] = {}

    def __init__(self, logger: Logger, name: str):
        self.logger = logger
        self.name = name

    def __new__(cls, _: Logger, name: str):
        if name not in cls._instances:
            cls._instances[name] = super().__new__(cls)
            logger = logging.getLogger(name)
            cls._instances[name].logger = logger
            cls._instances[name].name = name
        return cls._instances[name]

    def info(self, message: str, extra: Optional[dict[str, Any]] = None):
        self.logger.info(message, extra=extra)

    def debug(self, message: str, extra: Optional[dict[str, Any]] = None):
        self.logger.debug(message, extra=extra)

    def error(self, message: str, extra: Optional[dict[str, Any]] = None):
        self.logger.debug(message, extra=extra)



