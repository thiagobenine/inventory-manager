from logging import Logger
import logging
from typing import Any, Dict
from myloglib.formatters.new_relic_correlation import Correlation

class SingletonMeta(type):
    _instances:dict = {}

    def __call__(cls, *args, **kwargs):
        name = kwargs.get('name', '') if kwargs else args[0] if args else 'default'
        
        if (cls, name) not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[(cls, name)] = instance
        
        # Retorna a instância existente ou recém-criada
        return cls._instances[(cls, name)]

class StandardLogger(metaclass=SingletonMeta):
    def __init__(self, logger: Logger, name: str):
        self.logger = logger
        self.name = name

    @classmethod
    def create(cls, name):
        logger = logging.getLogger(name)
        return cls(logger, name=name)

    def info(self, message: str, context: Dict[str, Any] = None):
        self.logger.info(message, extra={"key": "value"})

    def debug(self, message: str, context: Dict[str, Any] = None):
        self.logger.debug(message, extra={"key": "value"})

    def error(self, message: str, context: Dict[str, Any] = None):
        self.logger.error(message, extra={"key": "value"})



