from contextvars import ContextVar
from newrelic.api.log import NewRelicContextFormatter
from typing import Optional
import inspect
import os
class CorrelationIDNewRelicContextFormatter(NewRelicContextFormatter):
    correlation_id: Optional[ContextVar] = None  

    def __init__(self, correlation_id: Optional[ContextVar] = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if correlation_id is not None:
            CorrelationIDNewRelicContextFormatter.correlation_id = correlation_id

    @classmethod
    def _get_caller_info(cls):
        stack = inspect.stack()
        for frame in reversed(stack):
            if frame.filename.endswith('.py') and 'python' not in frame.filename.lower():
                return frame.filename, frame.lineno
        return None, None
    
    @classmethod
    def log_record_to_dict(cls, record, stack_trace_limit=0):
        output = super().log_record_to_dict(record, stack_trace_limit)
        if cls.correlation_id is not None:
            try:
                output['correlation_id'] = cls.correlation_id.get()
            except LookupError:
                pass
        
        caller_filepath, caller_lineno = cls._get_caller_info()
        
        if caller_filepath and caller_lineno:
            output['caller_filepath'] = os.path.relpath(caller_filepath)
            output['caller_lineno'] = caller_lineno
            output['file.name'] = os.path.relpath(caller_filepath)
            output['line.number'] = caller_lineno
        
        return output