from contextvars import ContextVar
from newrelic.api.log import NewRelicContextFormatter
from typing import Optional

class CorrelationIDNewRelicContextFormatter(NewRelicContextFormatter):
    correlation_id: Optional[ContextVar] = None  

    def __init__(self, correlation_id: Optional[ContextVar] = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if correlation_id is not None:
            CorrelationIDNewRelicContextFormatter.correlation_id = correlation_id

    @classmethod
    def log_record_to_dict(cls, record):
        output = super().log_record_to_dict(record)
        if cls.correlation_id is not None:
            try:
                output['correlation_id'] = cls.correlation_id.get()
            except LookupError:
                pass
        return output
